/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication22;

/**
 *
 * @author HP
 */
public class ToohotCoffee extends Exception {
     String message;
    public ToohotCoffee(String messge){
        this.message=message;
    }
    public ToohotCoffee(){
        this.message="Too hot coffee";
    }
    public String getMessage(){
        return this.message;
    }
}
