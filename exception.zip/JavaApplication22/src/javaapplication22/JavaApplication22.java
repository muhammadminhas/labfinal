/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication22;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author HP
 */
public class JavaApplication22 {
    public static void main(String[] args) {
         Coffeecup obj=new Coffeecup();
        try {
            obj.takecoffee(40);
        } catch (ToohotCoffee ex) {
            System.out.println(ex.getMessage());
        } catch (ToocoldCoffee ex) {
            System.out.println(ex.getMessage());
        }
         
    }
    
}
